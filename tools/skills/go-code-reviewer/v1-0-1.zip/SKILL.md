---
name: go-code-reviewer
description: Expert Go code review
---

# go-code-reviewer Skill

A skill for [describe purpose].

## Quick Start

[Provide overview and how to use the skill]

## Implementation Workflow

### Step 1:
### Step 2:

## Knowledge Areas
[Provide Knowledge reference of the skill to file folder ./reference]

- Area 1
- Area 2
- Area 3

## Best Practices

1. Best practice 1
2. Best practice 2
3. Best practice 3

## Patterns

### Pattern 1

[Describe pattern]

```
Code example should be in ./examples folder]
```

### Pattern 2

[Describe pattern]

```
[Code example should be in ./examples folder]
```

## Common Pitfalls

- Pitfall 1
- Pitfall 2

## Resources
[Provide Resource reference of the skill to file folder ./reference]

- Resource 1
- Resource 2

